import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import urllib2,urllib

AddonTitle="[COLOR ghostwhite]TDB[/COLOR] [COLOR lightsteelblue]Wizard[/COLOR]"
Repo = "https://archive.org/download/repository.tdbegley"
Addons = "https://github.com/tdbegley28/TB-Wizard/tree/master/zips"
JarvisWiz = "https://archive.org/download/wizard_rel_201604/wizard_rel.txt"
JarvisCheck = "https://archive.org/download/wizard_rel_201604/version_check.txt"
JarvisUpdate = "https://archive.org/download/wizard_rel_201604/update_wiz.txt"
KryptonWiz = "https://ia801505.us.archive.org/10/items/tdb_krypton/krypton_wizard.txt"
KryptonCheck = "https://archive.org/download/tdb_krypton/version_check.txt"
KryptonUpdate = "https://archive.org/download/tdb_krypton/update_wiz.txt"

def Check():

	RepoStatus = "[COLOR green]UP[/COLOR]"
	AddonsStatus = "[COLOR green]UP[/COLOR]"
	JarvisWizStatus = "[COLOR green]UP[/COLOR]"
	JarvisCheckStatus = "[COLOR green]UP[/COLOR]"
	JarvisUpdateStatus = "[COLOR green]UP[/COLOR]"
	KryptonWizStatus = "[COLOR green]UP[/COLOR]"
	KryptonCheckStatus = "[COLOR green]UP[/COLOR]"
	KryptonUpdateStatus = "[COLOR green]UP[/COLOR]"
	dialog = xbmcgui.Dialog()

	xbmc.executebuiltin( "ActivateWindow(busydialog)" )

	try:
		response = urllib2.urlopen(Repo)
	except:
		RepoStatus = "[COLOR red]DOWN[/COLOR]"
	
	try:
		response = urllib2.urlopen(Addons)
	except:
		AddonsStatus = "[COLOR red]DOWN[/COLOR]"
	
	try:
		response = urllib2.urlopen(JarvisWiz)
	except:
		JarvisWizStatus = "[COLOR red]DOWN[/COLOR]"
	
	try:
		response = urllib2.urlopen(JarvisCheck)
	except:
		JarvisCheckStatus = "[COLOR red]DOWN[/COLOR]"
	
	try:
		response = urllib2.urlopen(JarvisUpdate)
	except:
		JarvisUpdateStatus = "[COLOR red]DOWN[/COLOR]"
	
	try:
		response = urllib2.urlopen(KryptonWiz)
	except:
		KryptonWizStatus = "[COLOR red]DOWN[/COLOR]"
	
	try:
		response = urllib2.urlopen(KryptonCheck)
	except:
		KryptonCheckStatus = "[COLOR red]DOWN[/COLOR]"
	
	try:
		response = urllib2.urlopen(KryptonUpdate)
	except:
		KryptonUpdateStatus = "[COLOR red]DOWN[/COLOR]"

	xbmc.executebuiltin( "Dialog.Close(busydialog)" ) 

	dialog.ok(AddonTitle,'[COLOR lightsteelblue][I]TDB Repository: [/COLOR][/I]| Repo ZIP: ' + RepoStatus + ' | REPO Addons: ' + AddonsStatus, '[COLOR lightsteelblue][I]Jarvis Servers: [/COLOR][/I]| Builds: ' + JarvisWizStatus + ' | Updates: ' + JarvisUpdateStatus + ' | Version Checker: ' + JarvisCheckStatus, '[COLOR lightsteelblue][I]Krypton Servers:[/COLOR][/I] | Builds: ' + KryptonWizStatus + ' | Updates: ' + KryptonUpdateStatus + ' | Version Check: ' + KryptonCheckStatus)
