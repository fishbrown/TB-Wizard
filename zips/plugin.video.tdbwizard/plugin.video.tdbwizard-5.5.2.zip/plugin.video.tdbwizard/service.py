import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
from addon.common.addon import Addon
import urllib2,urllib
import extract
import downloader
import re
import time
import common as Common
import wipe

USERDATA     =  xbmc.translatePath(os.path.join('special://home/userdata',''))
CHECKVERSION  =  os.path.join(USERDATA,'version.txt')
WIPE  =  xbmc.translatePath('special://home/wipe.xml')
CLEAN  =  xbmc.translatePath('special://home/clean.xml')
my_addon = xbmcaddon.Addon()
dp = xbmcgui.DialogProgress()
checkver=my_addon.getSetting('checkupdates')
dialog = xbmcgui.Dialog()
AddonTitle="[COLOR ghostwhite]TDB[/COLOR] [COLOR lightsteelblue]Wizard[/COLOR]"

if os.path.exists(CHECKVERSION):
	checkurl = "https://archive.org/download/wizard_rel_201604/version_check.txt"
	vers = open(CHECKVERSION, "r")
	regex = re.compile(r'<build>(.+?)</build><version>(.+?)</version>')
	for line in vers:
		if checkver!='false':
			currversion = regex.findall(line)
			for build,vernumber in currversion:
				if vernumber > 0:
					req = urllib2.Request(checkurl)
					req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
					response = urllib2.urlopen(req)
					link=response.read()
					response.close()
					match = re.compile('<build>'+build+'</build><version>(.+?)</version><fresh>(.+?)</fresh>').findall(link)
					for newversion,fresh in match:
						if newversion > vernumber:
							choice = xbmcgui.Dialog().yesno("NEW UPDATE AVAILABLE", 'Found a new update for the Build', build + " ver: "+newversion, 'Do you want to install it now?', yeslabel='[B][COLOR green]YES[/COLOR][/B]',nolabel='[B][COLOR red]NO[/COLOR][/B]')
							if choice == 1: 
								if fresh =='false': # TRUE
									updateurl = "https://archive.org/download/wizard_rel_201604/update_wiz.txt"
									req = urllib2.Request(updateurl)
									req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
									response = urllib2.urlopen(req)
									link=response.read()
									response.close()
									match = re.compile('<build>'+build+'</build><url>(.+?)</url>').findall(link)
									for url in match:
									
										path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
										name = "build"
										dp = xbmcgui.DialogProgress()
	
										dp.create(AddonTitle,"Downloading ",'', 'Please Wait')
										lib=os.path.join(path, name+'.zip')
										try:
											os.remove(lib)
										except:
											pass
										
										downloader.download(url, lib, dp)
										addonfolder = xbmc.translatePath(os.path.join('special://','home'))
										time.sleep(2)
										dp.update(0,"", "Extracting Zip Please Wait")
										print '======================================='
										print addonfolder
										print '======================================='
										extract.all(lib,addonfolder,dp)
										dialog = xbmcgui.Dialog()
										dialog.ok(AddonTitle, "To save changes you now need to force close Kodi, Press OK to force close Kodi")
										
										Common.KillKodi()
										
								else:
									dialog.ok('[COLOR red]A WIPE is required for the update[/COLOR]','Select the [COLOR green]YES[/COLOR] option in the NEXT WINDOW to wipe now.','Select the [COLOR red]NO[/COLOR] option in the NEXT WINDOW to update later.','[I][COLOR snow]If you wish to update later you can do so in [/COLOR][COLOR blue]TDB[/COLOR] [COLOR lime]Wizard[/COLOR][/I]')
									wipe.FRESHSTART()
			
if os.path.exists(CHECKVERSION):
	checkurl = "https://archive.org/download/tdb_krypton/version_check.txt"
	vers = open(CHECKVERSION, "r")
	regex = re.compile(r'<build>(.+?)</build><version>(.+?)</version>')
	for line in vers:
		if checkver!='false':
			currversion = regex.findall(line)
			for build,vernumber in currversion:
				if vernumber > 0:
					req = urllib2.Request(checkurl)
					req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
					response = urllib2.urlopen(req)
					link=response.read()
					response.close()
					match = re.compile('<build>'+build+'</build><version>(.+?)</version><fresh>(.+?)</fresh>').findall(link)
					for newversion,fresh in match:
						if newversion > vernumber:
							choice = xbmcgui.Dialog().yesno("NEW UPDATE AVAILABLE", 'Found a new update for the Build', build + " ver: "+newversion, 'Do you want to install it now?', yeslabel='[B][COLOR green]YES[/COLOR][/B]',nolabel='[B][COLOR red]NO[/COLOR][/B]')
							if choice == 1: 
								if fresh =='false': # TRUE
									updateurl = "https://archive.org/download/tdb_krypton/update_wiz.txt"
									req = urllib2.Request(updateurl)
									req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
									response = urllib2.urlopen(req)
									link=response.read()
									response.close()
									match = re.compile('<build>'+build+'</build><url>(.+?)</url>').findall(link)
									for url in match:
									
										path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
										name = "build"
										dp = xbmcgui.DialogProgress()
	
										dp.create(AddonTitle,"Downloading ",'', 'Please Wait')
										lib=os.path.join(path, name+'.zip')
										try:
											os.remove(lib)
										except:
											pass
										
										downloader.download(url, lib, dp)
										addonfolder = xbmc.translatePath(os.path.join('special://','home'))
										time.sleep(2)
										dp.update(0,"", "Extracting Zip Please Wait")
										print '======================================='
										print addonfolder
										print '======================================='
										extract.all(lib,addonfolder,dp)
										dialog = xbmcgui.Dialog()
										dialog.ok(AddonTitle, "To save changes you now need to force close Kodi, Press OK to force close Kodi")
										
										Common.KillKodi()
										
								else:
									dialog.ok('[COLOR red]A WIPE is required for the update[/COLOR]','Select the [COLOR green]YES[/COLOR] option in the NEXT WINDOW to wipe now.','Select the [COLOR red]NO[/COLOR] option in the NEXT WINDOW to update later.','[I][COLOR orange]If you wish to update later you can do so in [/COLOR][COLOR blue]TDB[/COLOR] [COLOR lime]Wizard[/COLOR][/I]')
									wipe.FRESHSTART()

if os.path.exists(WIPE):
	choice = xbmcgui.Dialog().yesno(AddonTitle, '[COLOR slategray]A system reset has been successfully performed.[/COLOR]','Your device has now returned to factory settings.','[COLOR lightsteelblue][I]Would you like to run the TDB Wizard and install a build now?[/COLOR][/I]', yeslabel='[COLOR green][B]YES[/B][/COLOR]',nolabel='[COLOR red][B]NO[/B][/COLOR]')
	if choice == 1: 
		os.remove(WIPE)
		xbmc.executebuiltin("RunAddon(plugin.video.tdbwizard)")
	else:
		os.remove(WIPE)

## ################################################## ##
## ################################################## ##