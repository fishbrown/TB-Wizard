import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import glob
import extract
import downloader
import requests
import speedtest
import time
import plugintools
from addon.common.addon import Addon
from addon.common.net import Net
import CheckPath
import zipfile
import ntpath
import errno
import common as Common
import wipe
import autoclean
import versioncheck
import ServerStatus

JarvisWiz = "https://archive.org/download/wizard_rel_201604/wizard_rel.txt"
KryptonWiz = "https://ia801505.us.archive.org/10/items/tdb_krypton/krypton_wizard.txt"
JarvisOne = "https://archive.org/download/wizard_rel_201604/update_wiz.txt"
JarvisTwo = "https://archive.org/download/wizard_rel_201604/version_check.txt"
KryptonOne = "https://archive.org/download/tdb_krypton/update_wiz.txt"
KryptonTwo = "https://archive.org/download/tdb_krypton/version_check.txt"
paramsscore = plugintools.get_params()
thumbnailPath = xbmc.translatePath('special://userdata/Thumbnails');
cachePath = os.path.join(xbmc.translatePath('special://home'), 'cache')
tempPath = xbmc.translatePath('special://temp')
addonPath = os.path.join(os.path.join(xbmc.translatePath('special://home'), 'addons'),'plugin.video.tdbwizard')
mediaPath = os.path.join(addonPath, 'resources/art')
databasePath = xbmc.translatePath('special://userdata/Database')
AddonData = xbmc.translatePath('special://userdata/addon_data')
addon_id = 'plugin.video.tdbwizard'
ADDON = xbmcaddon.Addon(id=addon_id)
AddonID='plugin.video.tdbwizard'
AddonTitle="[COLOR ghostwhite]TDB[/COLOR] [COLOR lightsteelblue]Wizard[/COLOR]"
MaintTitle="[COLOR ghostwhite]TDB[/COLOR] [COLOR lightsteelblue]Maintenance Tools[/COLOR]"
dialog       =  xbmcgui.Dialog()
net = Net()
HOME         =  xbmc.translatePath('special://home/')
dp           =  xbmcgui.DialogProgress()
U = ADDON.getSetting('User')
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))
VERSION = "1.19"
DBPATH = xbmc.translatePath('special://userdata/Database')
TNPATH = xbmc.translatePath('special://userdata/Thumbnails');
PATH = "TDB Wizard"            
BASEURL = "http://test.com"
H = 'http://'
skin         =  xbmc.getSkinDir()
EXCLUDES     = ['plugin.video.tdbwizard','script.module.addon.common','repository.tdbegley.official','script.module.requests','temp','kodi.log','kodi.log.old','spmc.log','spmc.log.old']

ARTPATH      =  '' + os.sep
UPDATEPATH     =  xbmc.translatePath(os.path.join('special://home/addons',''))
UPDATEADPATH	=  xbmc.translatePath(os.path.join('special://home/userdata/addon_data',''))
USERDATA     =  xbmc.translatePath(os.path.join('special://home/userdata',''))
MEDIA        =  xbmc.translatePath(os.path.join('special://home/media',''))
AUTOEXEC     =  xbmc.translatePath(os.path.join(USERDATA,'autoexec.py'))
AUTOEXECBAK  =  xbmc.translatePath(os.path.join(USERDATA,'autoexec_bak.py'))
ADDON_DATA   =  xbmc.translatePath(os.path.join(USERDATA,'addon_data'))
PLAYLISTS    =  xbmc.translatePath(os.path.join(USERDATA,'playlists'))
DATABASE     =  xbmc.translatePath(os.path.join(USERDATA,'Database'))
ADDONS       =  xbmc.translatePath(os.path.join('special://home','addons',''))
CBADDONPATH  =  xbmc.translatePath(os.path.join(ADDONS,AddonID,'default.py'))
GUISETTINGS  =  os.path.join(USERDATA,'guisettings.xml')
GUI          =  xbmc.translatePath(os.path.join(USERDATA,'guisettings.xml'))
GUIFIX       =  xbmc.translatePath(os.path.join(USERDATA,'guifix.xml'))
INSTALL      =  xbmc.translatePath(os.path.join(USERDATA,'install.xml'))
FAVS         =  xbmc.translatePath(os.path.join(USERDATA,'favourites.xml'))
SOURCE       =  xbmc.translatePath(os.path.join(USERDATA,'sources.xml'))
ADVANCED     =  xbmc.translatePath(os.path.join(USERDATA,'advancedsettings.xml'))
PROFILES     =  xbmc.translatePath(os.path.join(USERDATA,'profiles.xml'))
RSS          =  xbmc.translatePath(os.path.join(USERDATA,'RssFeeds.xml'))
KEYMAPS      =  xbmc.translatePath(os.path.join(USERDATA,'keymaps','keyboard.xml'))
WIPE 		 =  xbmc.translatePath('special://home/wipe.xml')
CLEAN 		 =  xbmc.translatePath('special://home/clean.xml')
FRESH        = 0
notifyart    =  xbmc.translatePath(os.path.join(ADDONS,AddonID,'resources/'))
skin         =  xbmc.getSkinDir()
userdatafolder = xbmc.translatePath(os.path.join(ADDON_DATA,AddonID))
zip = 'special://home/addons/plugin.video.tdbwizard'
urlbase      =  'None'
mastercopy   =  ADDON.getSetting('mastercopy')
dialog = xbmcgui.Dialog()
urlupdate =  ""
updatename =  "tdb_update"
CHECKVERSION  =  os.path.join(USERDATA,'version.txt')
my_addon = xbmcaddon.Addon()
dp = xbmcgui.DialogProgress()
checkver=my_addon.getSetting('checkupdates')
dialog = xbmcgui.Dialog()

#######################################################################
#                           NEWS
#######################################################################

def ReportBug():
    
    dialog = xbmcgui.Dialog()
    dialog.ok(AddonTitle, "[B][I]To report a bug please visit the issues section on GitHub", " ", "[COLOR lightsteelblue][B][I]GitHub[/COLOR][/B][/I] : http://tinyurl.com/zg82qtq")	

#######################################################################
#                       Support
#######################################################################
def SupportText():
    
    dialog = xbmcgui.Dialog()
    dialog.ok(AddonTitle, "[B][I][COLOR ghostwhite]TDB[/COLOR] [COLOR lightsteelblue]WIZARD[/COLOR][/B][/I] | KODI | SPMC | XBMC | Builds & Support", "[COLOR lightsteelblue][B][I]GitHub[/COLOR][/B][/I] : https://github.com/tdbegley28/TB-Wizard", "[COLOR lightsteelblue][B][I]Facebook[/COLOR][/B][/I] : http://tinyurl.com/zf4wekm ")
        
#######################################################################
#                       Compatibility
#######################################################################
def NotCompatible():
    
    dialog = xbmcgui.Dialog()
    dialog.ok(AddonTitle, "[B][COLOR powderblue]Important Notice: [/COLOR][/B]",'[COLOR white]TDB Builds are not compatabile with any Kodi versions before 16 Jarvis.','TDB Builds will NOT work with Frodo, Gotham and Isengard versions of Kodi.[/COLOR]')

#######################################################################
#						Cache Functions
#######################################################################

class Gui(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        xbmcgui.WindowXMLDialog.__init__(self)
        self.header = kwargs.get("header")
        self.content = kwargs.get("content")

    def onInit(self):
        self.getControl(1).setLabel(self.header)
        self.getControl(5).setText(self.content)

path   = xbmcaddon.Addon().getAddonInfo('path').decode("utf-8")

class cacheEntry:
    def __init__(self, namei, pathi):
        self.name = namei
        self.path = pathi

############################
###GET PARAMS###############
############################

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

#---------------------------------------------------------------------------------------------------
# Addon starts here
params=get_params()
url=None
name=None
buildname=None
updated=None
author=None
version=None
mode=None
iconimage=None
description=None
video=None
link=None
skins=None
videoaddons=None
audioaddons=None
programaddons=None
audioaddons=None
sources=None
local=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        guisettingslink=urllib.unquote_plus(params["guisettingslink"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        mode=str(params["mode"])
except:
        pass
try:
        link=urllib.unquote_plus(params["link"])
except:
        pass
try:
        skins=urllib.unquote_plus(params["skins"])
except:
        pass
try:
        videoaddons=urllib.unquote_plus(params["videoaddons"])
except:
        pass
try:
        audioaddons=urllib.unquote_plus(params["audioaddons"])
except:
        pass
try:
        programaddons=urllib.unquote_plus(params["programaddons"])
except:
        pass
try:
        pictureaddons=urllib.unquote_plus(params["pictureaddons"])
except:
        pass
try:
        local=urllib.unquote_plus(params["local"])
except:
        pass
try:
        sources=urllib.unquote_plus(params["sources"])
except:
        pass
try:
        adult=urllib.unquote_plus(params["adult"])
except:
        pass
try:
        buildname=urllib.unquote_plus(params["buildname"])
except:
        pass
try:
        updated=urllib.unquote_plus(params["updated"])
except:
        pass
try:
        version=urllib.unquote_plus(params["version"])
except:
        pass
try:
        author=urllib.unquote_plus(params["author"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:        
        video=urllib.unquote_plus(params["video"])
except:
        pass		
		
#######################################################################
#						Add to menus
#######################################################################

def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        if mode==90 :
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addItem(name,url,mode,iconimage,fanart,description):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&fanart="+urllib.quote_plus(fanart)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	liz.setProperty( "Fanart_Image", fanart )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok

def addDirWTW(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addLink(name,url,iconimage):
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
	return ok

#######################################################################
#						Root Menu
#######################################################################

def INDEX():

	addItem('[B][COLOR ghostwhite]-------------- [COLOR orange]CHECK SERVER STATUS[/COLOR] --------------[/COLOR][/B]',BASEURL,92,ART+'icon.png',FANART,'')
	addItem('[B][COLOR ghostwhite]----------- [COLOR lightsteelblue]FOLLOW THE STEPS BELOW[/COLOR] -----------[/COLOR][/B]',BASEURL,8,ART+'icon.png',FANART,'')
	addDir('[B][COLOR lightsteelblue]STEP 1 - [COLOR ghostwhite]SYSTEM RESET [COLOR white][/B][I](Performs a factory reset and deletes everything)[/I][/COLOR][/COLOR]','url',6,ART+'icon.png',FANART,'')
	addDir('[B][COLOR lightsteelblue]STEP 2 - [COLOR ghostwhite]INSTALL A TDB[/COLOR] [COLOR lightsteelblue]BUILD [I][/B][COLOR white](Supported: Kodi 16 Jarvis, SPMC 16 and Kodi 17 Krypton ONLY)[/I][/COLOR][/COLOR]',BASEURL,88,ART+'icon.png',FANART,'')
	addDir('[B][COLOR lightsteelblue]STEP 3 - [COLOR ghostwhite]ADVANCED SETTINGS TOOL [COLOR white][/B][I](Helps with buffering issues)[/I][/COLOR][/COLOR]',BASEURL,30,ART+'icon.png',FANART,'')
	addItem('[B][COLOR ghostwhite]----------------------- [COLOR lightsteelblue]ESSENTIALS[/COLOR] ----------------------[/COLOR][/B]',BASEURL,8,ART+'icon.png',FANART,'')
	addItem('[B][I][COLOR slategray]CHECK FOR UPDATES NOW [/COLOR][/B][COLOR white](Check all addon repositories for addon updates and check the TDB server to see if any updates are available for your build.)[/COLOR][/I]',BASEURL,11,ART+'icon.png',FANART,'')
	addItem('[B][I][COLOR slategray]CAN I INSTALL A TDB BUILD ON THIS SYSTEM? [/COLOR][/B][COLOR white](TDB Wizard builds are only compatable with Kodi/SPMC 16.0 Jarvis and above, check if your version is compatable here.)[/COLOR][/I]',BASEURL,14,ART+'icon.png',FANART,'')
	addDir('[B][I][COLOR slategray]SPEED TEST [/COLOR][/B][COLOR white](Check how well your system can handle streams with the speed test tool)[/COLOR][/I]',BASEURL,16,ART+'icon.png',ART+'speedfanart.jpg','')
	addItem('[B][COLOR ghostwhite]-------------------------- [COLOR lightsteelblue]EXTRAS[/COLOR] --------------------------[/COLOR][/B]',BASEURL,8,ART+'icon.png',FANART,'')
	addDir('[B][COLOR ghostwhite]MAINTENANCE TOOLS [COLOR white][/B][I](Auto clean, clear cache, purge packages, delete thumbnails, convert physical to special etc)[/I][/COLOR][/COLOR]',BASEURL,5,ART+'icon.png',ART+'maintwall.jpg','')
	addItem('[B][COLOR ghostwhite]-------------------------- [COLOR lightsteelblue]SPORTS[/COLOR] --------------------------[/COLOR][/B]',BASEURL,8,ART+'icon.png',ART+'sportswall.jpg','')
	addDir('[B][COLOR ghostwhite]WHERE TO WATCH THE GAMES [COLOR white][/B][I](Football, Rugby, NFL etc)[/I][/COLOR][/COLOR]',BASEURL,99,ART+'icon.png',ART+'sportswall.jpg','')
	addItem('[B][COLOR ghostwhite]-------------------------- [COLOR lightsteelblue]SOCIAL[/COLOR] --------------------------[/COLOR][/B]',BASEURL,8,ART+'icon.png',FANART,'')
	addItem('[B][COLOR ghostwhite]SUPPORT & SUGGESTIONS?[/COLOR][/B]',BASEURL,8,ART+'icon.png',FANART,'')
	addItem('[B][COLOR ghostwhite]REPORT A BUG?[/COLOR][/B]',BASEURL,7,ART+'icon.png',FANART,'')
	
#######################################################################
#						Which Build Menu
#######################################################################

def BUILDMENU():

	Jarvis = 0
	Krypton = 0
	updownj = "[B][COLOR green]SERVER UP[/B][/COLOR]"
	updownk = "[B][COLOR green]SERVER UP[/B][/COLOR]"
	dialog = xbmcgui.Dialog()

	try:
	    response = urllib2.urlopen(JarvisWiz)
	except:
	    Jarvis = 1

	try:
	    response = urllib2.urlopen(KryptonWiz)
	except:
	    Krypton = 1

	if Jarvis == 1:
		updownj = "[B][COLOR red]SERVER DOWN[/B][/COLOR]"
	
	if Krypton == 1:
		updownk = "[B][COLOR red]SERVER DOWN[/B][/COLOR]"

	addItem('[B][I][COLOR powderblue]Which should I choose? [/COLOR][/B][COLOR white](Jarvis or Krypton?)[/COLOR][/I]',BASEURL,44,ART+'icon.png',FANART,'')
	addDir('[B][COLOR ghostwhite]INSTALL[/COLOR] | [COLOR lightsteelblue]Kodi/SPMC 16[/COLOR] (STABLE) - [COLOR lightsteelblue]Jarvis Builds[/COLOR] | [COLOR ghostwhite]Status: [/COLOR][/B]'+ updownj,BASEURL,19,ART+'HORUS.png',ART+'HORUS.png','')
	addDir('[B][COLOR ghostwhite]INSTALL[/COLOR] | [COLOR lightsteelblue]Kodi 17[/COLOR] (ALPHA) - [COLOR lightsteelblue]Krypton Builds[/COLOR] | [COLOR ghostwhite]Status: [/COLOR][/B]' + updownk,BASEURL,20,ART+'ARES.png',ART+'ARES.png','')
	addItem('[B][I][COLOR powderblue]IMPORTANT: TDB Builds are not compatabile with any Kodi versions before 16 Jarvis. TDB Builds will NOT work with Kodi Frodo, Gotham and Isengard versions of Kodi.[/B][/COLOR][/I]',BASEURL,45,ART+'icon.png',FANART,'')

#######################################################################
#						Jarvis Builds Menu
#######################################################################

def BUILDMENU_JARVIS():
    
    accept = 0
    Jarvis = 0
    dialog = xbmcgui.Dialog()
    xbmc_version=xbmc.getInfoLabel("System.BuildVersion")
    version=float(xbmc_version[:4])

    if version >= 16.0 and version <= 16.9:
		accept = 1

    if version >= 11.0 and version <= 11.9:
		codename = '[COLOR ghostwhite]Eden[/COLOR]'
    if version >= 12.0 and version <= 12.9:
		codename = '[COLOR ghostwhite]Frodo[/COLOR]'
    if version >= 13.0 and version <= 13.9:
		codename = '[COLOR ghostwhite]Gotham[/COLOR]'
    if version >= 14.0 and version <= 14.9:
		codename = '[COLOR ghostwhite]Helix[/COLOR]'
    if version >= 15.0 and version <= 15.9:
		codename = '[COLOR ghostwhite]Isengard[/COLOR]'
    if version >= 16.0 and version <= 16.9:
		codename = '[COLOR ghostwhite]Jarvis[/COLOR]'
    if version >= 17.0 and version <= 17.9:
		codename = '[COLOR ghostwhite]Krypton[/COLOR]'

    try:
        response = urllib2.urlopen(JarvisWiz)
    except:
        Jarvis = 1

    if accept == 1:	
        if Jarvis == 0:
	    	link = OPEN_URL(JarvisWiz).replace('\n','').replace('\r','')
	    	match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?ersion="(.+?)"').findall(link)
	    	for name,url,iconimage,fanart,description in match:
			addDir("[COLOR ghostwhite][I]Build[/COLOR][/I]  | " + name + " - [COLOR lightsteelblue][I]Version[/COLOR][/I]  | " + description + " - [COLOR powderblue][I]Maintainer[/COLOR][/I]  | TDB Wizard ",url,90,ART+name+'.png',ART+name+'.png',description)
        else:
	    	dialog.ok(AddonTitle,'Sorry we are unable to get the Jarvis Build list at this time.','The Jarvis host appears to be down.','[I][COLOR lightsteelblue]Plese try again later.[/COLOR][/I]')
    else:
    	dialog.ok(AddonTitle, "Sorry we are unable to process your request","[COLOR red][I][B]Error: You are not running Kodi Jarvis[/COLOR][/I][/B]","[I]Your are running: [COLOR lightsteelblue][B]Kodi " + codename + " Version:[COLOR ghostwhite] %s" % version + "[/COLOR][/I][/B][/COLOR]")

#######################################################################
#						Krypton Builds Menu
#######################################################################

def BUILDMENU_KRYPTON():
    
    accept = 0
    Krypton = 0
    dialog = xbmcgui.Dialog()
    xbmc_version=xbmc.getInfoLabel("System.BuildVersion")
    version=float(xbmc_version[:4])

    if version >= 17.0 and version <= 17.9:
		accept = 1

    if version >= 11.0 and version <= 11.9:
		codename = '[COLOR ghostwhite]Eden[/COLOR]'
    if version >= 12.0 and version <= 12.9:
		codename = '[COLOR ghostwhite]Frodo[/COLOR]'
    if version >= 13.0 and version <= 13.9:
		codename = '[COLOR ghostwhite]Gotham[/COLOR]'
    if version >= 14.0 and version <= 14.9:
		codename = '[COLOR ghostwhite]Helix[/COLOR]'
    if version >= 15.0 and version <= 15.9:
		codename = '[COLOR ghostwhite]Isengard[/COLOR]'
    if version >= 16.0 and version <= 16.9:
		codename = '[COLOR ghostwhite]Jarvis[/COLOR]'
    if version >= 17.0 and version <= 17.9:
		codename = '[COLOR ghostwhite]Krypton[/COLOR]'

    Krypton = 0
    dialog = xbmcgui.Dialog()

    try:
	    response = urllib2.urlopen(KryptonWiz)
    except:
	    Krypton = 1

    if accept == 1:	
		if Krypton == 0:
			link = OPEN_URL(KryptonWiz).replace('\n','').replace('\r','')
			match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?ersion="(.+?)"').findall(link)
			for name,url,iconimage,fanart,description in match:
				addDir("[COLOR ghostwhite][I]Build[/COLOR][/I]  | " + name + " - [COLOR lightsteelblue][I]Version[/COLOR][/I]  | " + description + " - [COLOR powderblue][I]Maintainer[/COLOR][/I]  | TDB Wizard ",url,90,ART+name+'.png',ART+name+'.png',description)
		else:
			dialog.ok(AddonTitle,'Sorry we are unable to get the Krypton Build list at this time.','The Krypton host appears to be down.','[I][COLOR lightsteelblue]Plese try again later.[/COLOR][/I]')
    else:
    	dialog.ok(AddonTitle, "Sorry we are unable to process your request","[COLOR red][I][B]Error: You are not running Kodi Krypton[/COLOR][/I][/B]","[I]Your are running: [COLOR lightsteelblue][B]Kodi " + codename + " Version:[COLOR ghostwhite] %s" % version + "[/COLOR][/I][/B][/COLOR]")

#######################################################################
#						Maintenance Menu
#######################################################################
	
def maintMenu():

    addDir('[B][I][COLOR white]Auto Clean Device[/COLOR][/I][/B]',HOME,31,os.path.join(ART, "icon.png"),ART+'maintwall.jpg','')
    addItem('[B][I][COLOR white]Clear Cache[/B][/I][/COLOR]','url', 1,os.path.join(ART, "icon.png"),ART+'maintwall.jpg','')
    addItem('[B][I][COLOR white]Delete Thumbnails[/B][/I][/COLOR]', 'url', 2,os.path.join(ART, "icon.png"),ART+'maintwall.jpg','')
    addItem('[B][I][COLOR white]Purge Packages[/B][/I][/COLOR]', 'url', 3,os.path.join(ART, "icon.png"),ART+'maintwall.jpg','')
    addItem('[B][I][COLOR white]Convert Physical Paths To Special[/COLOR][/I][/B]',HOME,13,os.path.join(ART, "icon.png"),ART+'maintwall.jpg','')

def SPEEDTEST():
    
    addDir('[B][COLOR lightsteelblue]THE LARGER THE FILE THE MORE ACCURATE THE RESULT.[/COLOR][/B]',BASEURL,16,ART+'icon.png',ART+'speedfanart.jpg','')
    addDir('[I][COLOR powderblue]A TEST IS DEPENDANT ON TWO FACTORS, THE SPEED YOU CAN DOWNLOAD THE FILE AND THE SPPED THE SERVER CAN GIVE THE FILE. YOU SHOULD TRY MORE THAN ONE LOCATION FOR THE BEST IDEA OF YOUR SPEED.[/COLOR][/I]',BASEURL,16,ART+'icon.png',ART+'speedfanart.jpg','')
    addDir('[B][COLOR ghostwhite]-------------------------- [COLOR lightsteelblue]SPEED TEST LIST[/COLOR] --------------------------[/COLOR][/B]',BASEURL,16,ART+'icon.png',ART+'speedfanart.jpg','')
    link = OPEN_URL('https://archive.org/download/tdb_speedtest/speedtest.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?ersion="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addItem(name + " | " + description,url,15,ART+'icon.png',ART+'speedfanart.jpg','')
	
def ADVANCEDSETTINGS():
    
    link = OPEN_URL('https://archive.org/download/tdbadvanced/wizard_rel.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?ersion="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name + " ver:" + description,url,91,ART+'icon.png',FANART,description)

############################
###INSTALL BUILD############
############################

def WIZARD(name,url,description):
	#Check is the packages folder exists, if not create it.
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    if not os.path.exists(path):
        os.makedirs(path)

    if FRESH == 1:
	dialog = xbmcgui.Dialog()
        dialog.ok(AddonTitle,'Please switch to the default Confluence skin','before proceeding.','')
        xbmc.executebuiltin("ActivateWindow(appearancesettings)")
        return
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    name = "build"
    dp = xbmcgui.DialogProgress()

    dp.create(AddonTitle,"Downloading Build",'', '')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
	
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(2)
    dp.update(0,"", "Extracting Zip Please Wait")
    print '======================================='
    print addonfolder
    print '======================================='
    extract.all(lib,addonfolder,dp)
    dialog = xbmcgui.Dialog()
    dialog.ok(AddonTitle, "To save changes you now need to force close Kodi, Press OK to force close Kodi")
    
    Common.killxbmc()
	
############################
###INSTALL ADVANCED SETTINGS
############################

def ADVANCEDXML(name,url,description):
    if FRESH == 1:
	dialog = xbmcgui.Dialog()
        dialog.ok(AddonTitle,'Please switch to the default Confluence skin','before proceeding.','')
        xbmc.executebuiltin("ActivateWindow(appearancesettings)")
        return
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    name = "build"
    dp = xbmcgui.DialogProgress()

    dp.create(AddonTitle,"Downloading Advanced Settings Zip File",'', '')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
	
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(2)
    dp.update(0,"", "Extracting Zip Please Wait")
    print '======================================='
    print addonfolder
    print '======================================='
    extract.all(lib,addonfolder,dp)
    dialog = xbmcgui.Dialog()
    dialog.ok(AddonTitle, "To save changes you now need to force close Kodi, Press OK to force close Kodi")
    
    Common.killxbmc()

############################
###CHECK FOR UPDATES########
############################

def updatecheck():

    dp.create(AddonTitle,"Checking all repositories for addon updates.",'[COLOR slategray][I]This will take approximately 10 seconds.[/I][/COLOR]', 'Please wait...') 
    xbmc.executebuiltin("UpdateAddonRepos")
    time.sleep ( 10 )
    choice = xbmcgui.Dialog().yesno(AddonTitle,'All repositories have been checked for updates.','[COLOR lightsteelblue]All available addon updates have now been installed.[/COLOR]','[COLOR slategray][I]Check for build updates now?[/COLOR][/I]', yeslabel='[B][COLOR green]YES[/COLOR][/B]',nolabel='[B][COLOR red]NO[/COLOR][/B]')
    if choice == 1:
	    if os.path.exists(CHECKVERSION):
        	update()
	    else:
			dialog.ok(AddonTitle,'You do not have a [COLOR lightsteelblue]TDB[/COLOR] [COLOR ghostwhite]Build[/COLOR] installed!')

def update():

	JarvisUpdate = 0
	KryptonUpdate = 0
	dialog = xbmcgui.Dialog()

	try:
	    response = urllib2.urlopen(JarvisTwo)
	except:
	    JarvisUpdate = 1
	    dialog.ok(AddonTitle,'Sorry we are unable to check for [B]JARVIS[/B] updates!','The Jarvis update host appears to be down.','[I][COLOR lightsteelblue]We will try the Krypton server next.[/COLOR][/I]')

	try:
	    response = urllib2.urlopen(KryptonTwo)
	except:
	    KryptonUpdate = 1
	    dialog.ok(AddonTitle,'Sorry we are unable to check for [B]KRYPTON[/B] updates!','The update host appears to be down.','Please check for updates later via the wizard.')

#######################################################################
#						Check for Jarvis Updates
#######################################################################

	if JarvisUpdate == 0:
		dialog = xbmcgui.Dialog()
		checkurl = JarvisTwo
		vers = open(CHECKVERSION, "r")
		regex = re.compile(r'<build>(.+?)</build><version>(.+?)</version>')
		for line in vers:
			if checkver!='false':
				currversion = regex.findall(line)
				for build,vernumber in currversion:
					if vernumber > 0:
						req = urllib2.Request(checkurl)
						req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
						try:
							response = urllib2.urlopen(req)
						except:
							dialog.ok(AddonTitle,'Sorry we are unable to check for [B]JARVIS[/B] updates!','The update host appears to be down.','Please check for updates later via the wizard.')
							sys.exit(1)					
						link=response.read()
						response.close()
						match = re.compile('<build>'+build+'</build><version>(.+?)</version><fresh>(.+?)</fresh>').findall(link)
						for newversion,fresh in match:
							if newversion > vernumber:
								choice = xbmcgui.Dialog().yesno("NEW UPDATE AVAILABLE", 'Found a new update for the Build', build + " ver: "+newversion, 'Do you want to install it now?', yeslabel='[B][COLOR green]YES[/COLOR][/B]',nolabel='[B][COLOR red]NO[/COLOR][/B]')
								if choice == 1: 
									if fresh =='false': # TRUE
										updateurl = JarvisOne
										req = urllib2.Request(updateurl)
										req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
										try:
											response = urllib2.urlopen(req)
										except:
											dialog.ok(AddonTitle,'Sorry we were unable to download the update!','The update host appears to be down.','Please check for updates later via the wizard.')
											sys.exit(1)									
										link=response.read()
										response.close()
										match = re.compile('<build>'+build+'</build><url>(.+?)</url>').findall(link)
										for url in match:
								
											path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
											name = "build"
											dp = xbmcgui.DialogProgress()

											dp.create(AddonTitle,"Downloading ",'', 'Please Wait')
											lib=os.path.join(path, name+'.zip')
											try:
												os.remove(lib)
											except:
												pass
									
											downloader.download(url, lib, dp)
											addonfolder = xbmc.translatePath(os.path.join('special://','home'))
											time.sleep(2)
											dp.update(0,"", "Extracting Zip Please Wait")
											print '======================================='
											print addonfolder
											print '======================================='
											extract.all(lib,addonfolder,dp)
											dialog.ok(AddonTitle, "To save changes you now need to force close Kodi, Press OK to force close Kodi")
										
											Common.killxbmc()
																		
									else:
										dialog.ok(AddonTitle,'[COLOR red]A WIPE (FACTORY RESET)[/COLOR] is required for the update... [COLOR red]WOULD YOU LIKE TO WIPE THE SYSTEM NOW?[/COLOR]','','')
										wipe.FRESHSTART()
							else:
								dialog.ok(AddonTitle,'Your build is up to date, No actions are required!', "Current Build: " + build, "Current Version: "+newversion)

#######################################################################
#						Check for Krypton Updates
#######################################################################

	if KryptonUpdate == 0:
		dialog = xbmcgui.Dialog()
		checkurl = KryptonTwo
		vers = open(CHECKVERSION, "r")
		regex = re.compile(r'<build>(.+?)</build><version>(.+?)</version>')
		for line in vers:
			if checkver!='false':
				currversion = regex.findall(line)
				for build,vernumber in currversion:
					if vernumber > 0:
						req = urllib2.Request(checkurl)
						req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
						try:
							response = urllib2.urlopen(req)
						except:
							dialog.ok(AddonTitle,'Sorry we are unable to check for [B]KRYPTON[/B] updates!','The update host appears to be down.','Please check for updates later via the wizard.')
							sys.exit(1)					
						link=response.read()
						response.close()
						match = re.compile('<build>'+build+'</build><version>(.+?)</version><fresh>(.+?)</fresh>').findall(link)	
						for newversion,fresh in match:
							if newversion > vernumber:
								choice = xbmcgui.Dialog().yesno("NEW UPDATE AVAILABLE", 'Found a new update for the Build', build + " ver: "+newversion, 'Do you want to install it now?', yeslabel='[B][COLOR green]YES[/COLOR][/B]',nolabel='[B][COLOR red]NO[/COLOR][/B]')
								if choice == 1: 
									if fresh =='false': # TRUE
										updateurl = KryptonOne
										req = urllib2.Request(updateurl)
										req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
										try:
											response = urllib2.urlopen(req)
										except:
											dialog.ok(AddonTitle,'Sorry we were unable to download the update!','The update host appears to be down.','Please check for updates later via the wizard.')
											sys.exit(1)									
										link=response.read()
										response.close()
										match = re.compile('<build>'+build+'</build><url>(.+?)</url>').findall(link)
										for url in match:
								
											path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
											name = "build"
											dp = xbmcgui.DialogProgress()

											dp.create(AddonTitle,"Downloading ",'', 'Please Wait')
											lib=os.path.join(path, name+'.zip')
											try:
												os.remove(lib)
											except:
												pass
									
											downloader.download(url, lib, dp)
											addonfolder = xbmc.translatePath(os.path.join('special://','home'))
											time.sleep(2)
											dp.update(0,"", "Extracting Zip Please Wait")
											print '======================================='
											print addonfolder
											print '======================================='
											extract.all(lib,addonfolder,dp)
											dialog.ok(AddonTitle, "To save changes you now need to force close Kodi, Press OK to force close Kodi")
										
											killxbmc()
																		
									else:
										dialog.ok('[COLOR red]A WIPE is required for the update[/COLOR]','Select the [COLOR green]YES[/COLOR] option in the NEXT WINDOW to wipe now.','Select the [COLOR red]NO[/COLOR] option in the NEXT WINDOW to update later.','[I][COLOR powderblue]If you wish to update later you can do so in [/COLOR][COLOR ghostwhite]TDB[/COLOR] [COLOR lightsteelblue]Wizard[/COLOR][/I]')
										wipe.FRESHSTART()

#######################################################################
#						Where to watch sports
#######################################################################

def upandcoming():
    url = 'http://www.wheresthematch.com/tv/home.asp'
    r = requests.get(url)
    match = re.compile('http://www\.wheresthematch\.com/fixtures/(.+?)\..+?channelid.+?">(.+?)<em class="livestream">Live Stream</em></a></span> <span class="ground">(.+?)</span>').findall(r.content)
    for game,image,name in match:
        addDirWTW('[COLOR powderblue]'+game+' [/COLOR]'+image+' '+'[COLOR ghostwhite]'+name+'[/COLOR]','','','')

#######################################################################
#						Maintenance Functions
#######################################################################
def setupCacheEntries():
    entries = 5 #make sure this refelcts the amount of entries you have
    dialogName = ["WTF", "4oD", "BBC iPlayer", "Simple Downloader", "ITV"]
    pathName = ["special://profile/addon_data/plugin.video.whatthefurk/cache", "special://profile/addon_data/plugin.video.4od/cache",
					"special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache","special://profile/addon_data/script.module.simple.downloader",
                    "special://profile/addon_data/plugin.video.itv/Images"]
                    
    cacheEntries = []
    
    for x in range(entries):
        cacheEntries.append(cacheEntry(dialogName[x],pathName[x]))
    
    return cacheEntries

#######################################################################
#						Clear Cache
#######################################################################

def clearCache():
    
    if os.path.exists(cachePath)==True:    
        for root, dirs, files in os.walk(cachePath):
            file_count = 0
            file_count += len(files)
            if file_count > 0:

                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete Kodi Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        try:
							if (f == "xbmc.log" or f == "xbmc.old.log" or f =="kodi.log" or f == "kodi.old.log" or f == "spmc.log" or f == "spmc.old.log"): continue
							os.unlink(os.path.join(root, f))
                        except:
                            pass
                    for d in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                        except:
                            pass
                        
            else:
                pass
    if os.path.exists(tempPath)==True:    
        for root, dirs, files in os.walk(tempPath):
            file_count = 0
            file_count += len(files)
            if file_count > 0:
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete Kodi Temp Files", str(file_count) + " files found", "Do you want to delete them?"):
                    for f in files:
                        try:
                            if (f == "kodi.log" or f == "kodi.old.log"): continue
                            os.unlink(os.path.join(root, f))
                        except:
                            pass
                    for d in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                        except:
                            pass
                        
            else:
                pass
    if xbmc.getCondVisibility('system.platform.ATV2'):
        atv2_cache_a = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')
        
        for root, dirs, files in os.walk(atv2_cache_a):
            file_count = 0
            file_count += len(files)
        
            if file_count > 0:

                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'Other'", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
        atv2_cache_b = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')
        
        for root, dirs, files in os.walk(atv2_cache_b):
            file_count = 0
            file_count += len(files)
        
            if file_count > 0:

                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'LocalAndRental'", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass    
                
    cacheEntries = setupCacheEntries()
                                         
    for entry in cacheEntries:
        clear_cache_path = xbmc.translatePath(entry.path)
        if os.path.exists(clear_cache_path)==True:    
            for root, dirs, files in os.walk(clear_cache_path):
                file_count = 0
                file_count += len(files)
                if file_count > 0:

                    dialog = xbmcgui.Dialog()
                    if dialog.yesno(MaintTitle,str(file_count) + "%s cache files found"%(entry.name), "Do you want to delete them?"):
                        for f in files:
                            os.unlink(os.path.join(root, f))
                        for d in dirs:
                            shutil.rmtree(os.path.join(root, d))
                            
                else:
                    pass
                

    dialog = xbmcgui.Dialog()
    dialog.ok(MaintTitle, "Done Clearing Cache files")
   
#######################################################################
#						Delete Thumbnails
#######################################################################
    
def deleteThumbnails():
    
    if os.path.exists(thumbnailPath)==True:  
            dialog = xbmcgui.Dialog()
            if dialog.yesno("Delete Thumbnails", "This option deletes all thumbnails", "Are you sure you want to do this?"):
                for root, dirs, files in os.walk(thumbnailPath):
                    file_count = 0
                    file_count += len(files)
                    if file_count > 0:                
                        for f in files:
                            try:
                                os.unlink(os.path.join(root, f))
                            except:
								pass
    else:
        pass
    
    text13 = os.path.join(databasePath,"Textures13.db")
    try:
		os.unlink(text13)
    except OSError:
        pass
		
	dialog.ok("Restart Kodi", "Please restart Kodi to rebuild thumbnail library")

#######################################################################
#						Delete Packages
#######################################################################

def purgePackages():
    
    purgePath = xbmc.translatePath('special://home/addons/packages')
    dialog = xbmcgui.Dialog()
    for root, dirs, files in os.walk(purgePath):
            file_count = 0
            file_count += len(files)
    if dialog.yesno("Delete Package Cache Files", "%d packages found."%file_count, "Delete Them?"):  
        for root, dirs, files in os.walk(purgePath):
            file_count = 0
            file_count += len(files)
            if file_count > 0:            
                for f in files:
                    os.unlink(os.path.join(root, f))
                for d in dirs:
                    shutil.rmtree(os.path.join(root, d))
                dialog = xbmcgui.Dialog()
                dialog.ok(MaintTitle, "Deleting Packages all done")
            else:
                dialog = xbmcgui.Dialog()
                dialog.ok(MaintTitle, "No Packages to Purge")
				
#######################################################################
#						Convert physical to special
#######################################################################	

def Fix_Special(url):

    dialog = xbmcgui.Dialog()
    dp.create(MaintTitle,"Renaming paths...",'', 'Please Wait')
    for root, dirs, files in os.walk(url):  #Search all xml files and replace physical with special
        for file in files:
            if file.endswith(".xml"):
                 dp.update(0,"Fixing",file, 'Please Wait')
                 a=open((os.path.join(root, file))).read()
                 b=a.replace(HOME, 'special://home/')
                 f = open((os.path.join(root, file)), mode='w')
                 f.write(str(b))
                 f.close()
				 
    dialog.ok(MaintTitle, "All physical paths converted to special")

#######################################################################
#						Open URL
#######################################################################

def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link  
         
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)

############################
###SET VIEW#################
############################

def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )

#######################################################################
#						Which mode to select
#######################################################################

if mode==None or url==None or len(url)<1:
        INDEX()

elif mode==99:
		upandcoming()
		
elif mode==1:
		clearCache()
        
elif mode==2:
		deleteThumbnails()

elif mode==3:
		purgePackages()
		
elif mode==5:
        maintMenu()
		
elif mode==7:
        ReportBug()
		
elif mode==8:
        SupportText()

elif mode==9:
        Suggestions()

elif mode==11:
        updatecheck()
		
elif mode==12:
        xbmc.executebuiltin("RunAddon(plugin.video.tdbwizard)")
		
elif mode==13:
        Fix_Special(url)

elif mode==14:
        versioncheck.XBMC_Version()
		
elif mode==44:
        versioncheck.BUILD_Version()

elif mode==45:
        NotCompatible()
		
elif mode==15:
        speedtest.runtest(url)
		
elif mode==16:
        SPEEDTEST()

elif mode==88:
        BUILDMENU()

elif mode==19:
        BUILDMENU_JARVIS()

elif mode==20:
        BUILDMENU_KRYPTON()
		
elif mode==21:
        CLEANUP(params)

elif mode==6:        
		wipe.FRESHSTART()
	
elif mode==30:
		ADVANCEDSETTINGS()
		
elif mode==31:
		autoclean.autocleanask()

elif mode==10:
		MAINTENANCE()
	
elif mode==85:
        print "############   ATTEMPT TO KILL XBMC/KODI   #################"
        Common.killxbmc()
		
elif mode==90:
        WIZARD(name,url,description)

elif mode==91:
        ADVANCEDXML(name,url,description)
		
elif mode==92:
        ServerStatus.Check()

xbmcplugin.endOfDirectory(int(sys.argv[1]))