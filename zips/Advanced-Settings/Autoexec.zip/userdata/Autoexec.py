#!/bin/sh

#This script runs when Kodi starts.
#It is used to scan and delete numerous files/folders
#
#The script deletes the following:
#
#All files & folders within special://home/temp
#
#Script written by Thomas Begley Contact: tdbegley28@gmail.com
#

import os
import shutil

#Define TEMP as the path to special://home/temp
TEMP = xbmc.translatePath(
    'special://home/temp'
    )

#Search the folder TEMP for all files with the extention .fi or .cache and delete them.
path = TEMP
exts = ('fi', '.cache')
if os.path.exists(TEMP):
    for root, dirs, files in os.walk(path):
        for currentFile in files:
            if any(currentFile.lower().endswith(ext) for ext in exts):
                os.remove(os.path.join(root, currentFile))