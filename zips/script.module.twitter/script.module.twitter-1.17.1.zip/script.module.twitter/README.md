# script.module.twitter

![Module Icon](http://icons.iconarchive.com/icons/limav/flat-gradient-social/512/Twitter-icon.png)

An API and command-line toolset for Twitter (twitter.com)

Website: http://mike.verdone.ca/twitter/
Source: https://pypi.python.org/pypi/twitter/1.16.0

Python module by Mike Verdone packaged for Kodi
