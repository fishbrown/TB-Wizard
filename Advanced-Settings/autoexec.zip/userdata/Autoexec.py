#!/bin/sh

#This script runs when Kodi starts.
#It is used to scan and delete numerous files/folders
#
#The script deletes the following:
#
#All files & folders within special://home/temp
#The packaes folder from special://home/addons
#The temp folder from Artwork Downloader
#The wallpapers folder from Skin Helper Service
#The musicart folder from Skin Helper Service
#The pvrthumbs folder from Skin Helper Service
#
#Script written by Thomas Begley Contact: tdbegley28@gmail.com
#

import os
import shutil

#Define tempPath as the path to special://home/temp
tempPath = xbmc.translatePath(
    'special://temp'
    )

#Define cachePath as the path to special://home/temp
cachePath = os.path.join(xbmc.translatePath('special://home'), 'cache')

#Define PACKAGES as the path to special://home/addons/packages
PACKAGES = xbmc.translatePath(
    'special://home/addons/packages'
    )

#Delete the temp folder(Android).
if os.path.exists(tempPath)==True:    
    for root, dirs, files in os.walk(tempPath):
        file_count = 0
        file_count += len(files)
        if file_count > 0:
            for f in files:
                try:
                    if (f == "xbmc.log" or f == "xbmc.old.log" or f =="kodi.log" or f == "kodi.old.log" or f == "spmc.log" or f == "spmc.old.log"): continue
                    os.unlink(os.path.join(root, f))
                except:
                    pass
            for d in dirs:
                try:
                    shutil.rmtree(os.path.join(root, d))
                except:
                    pass

#Delete the cache folder(PC).
if os.path.exists(cachePath)==True:    
    for root, dirs, files in os.walk(cachePath):
        file_count = 0
        file_count += len(files)
        if file_count > 0:
            for f in files:
                try:
                    if (f == "xbmc.log" or f == "xbmc.old.log" or f =="kodi.log" or f == "kodi.old.log" or f == "spmc.log" or f == "spmc.old.log"): continue
                    os.unlink(os.path.join(root, f))
                except:
                    pass
            for d in dirs:
                try:
                    shutil.rmtree(os.path.join(root, d))
                except:
                    pass

#Delete the packages folder.
folder = PACKAGES
if os.path.exists(PACKAGES):
    for the_file in os.listdir(folder):
        file_path = os.path.join(folder, the_file)
        try:
            if os.path.isfile(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path): shutil.rmtree(file_path)
            donevalue = '1'
        except Exception, e:
            print e
